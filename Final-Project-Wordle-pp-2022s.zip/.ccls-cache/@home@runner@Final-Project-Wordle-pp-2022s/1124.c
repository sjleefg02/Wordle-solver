#include "wordle_st.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>
#include <unistd.h>//for sleep

#define MAX_WORD       30000
#define WORD_LEN_MAX   5
#define TRY_MAX        6
#define ALPHABET_CNT   26

double point[ALPHABET_CNT] = {0.082,0.015,0.028,0.043,0.13,0.022,0.02,0.061,0.07,0.0015,0.0077,0.04,0.024,0.067,0.075,0.019,0.00095,0.06,0.063,0.091,0.028,0.0098,0.024,0.0015,0.02,0.00074};

struct word_status{
  char answer[WORD_LEN_MAX + 1];
  char result[WORD_LEN_MAX + 1];
};
struct word_status results[TRY_MAX];

struct word_data{
  char word[WORD_LEN_MAX + 1];
  double score;
  int unused_letter_cnt;
  struct word_data *next;
};
typedef struct word_data data;
data *library_head;
data word_list[MAX_WORD];




//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
//Initializing part
void build_word_lib(const char *file_path){
}

int init_game(const char *file_path)
{
  //initialize things for the game
  build_word_lib(file_path);
  return 0;
}
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<


//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
//Progressing the game part
void make_answer1()
{
  data *current_node = library_head;
  data *stored_node = malloc(sizeof(data));
  stored_node->word = NULL;
  stored_node->score = 5;
  
  for(int i = 3; i > 0; i--){
    while(current_node->next != NULL){
      if ((current_node->unused_letter_cnt == i)&&(stored_node->score > current_node->score))
        stored_node = current_node;
      current_node = current_node->next;
    }
    if (stored_node != NULL)
      break;
    }

  //results[0].answer = stored_node->word;
  for(int i = 0; i < WORD_LEN_MAX; i++)
    results[0].answer[i] = stored_node->word[i];
  }


int check_grey(int guess, char letter)
{
  for(int i = 0; i < WORD_LEN_MAX; i++){
    if(results[guess-1].answer[i] == letter && results[guess-1].result[i] == 'b') 
      return letter;
  }
  return 0;
}

/*void remove_grey(int guess)
{
  data *current_node = library_head;
  
  while(current_node->next != NULL){
    for(int i = 0; i < WORD_LEN_MAX; i++)
      if(results[guess-1].result[i] == 'b')
        
    current_node = current_node->next;
  }
}*/

void removeFirst(data *target)
{
  data *removeNode = target->next;
  target->next = removeNode->next;
  free(removeNode);
}

void remove_grey()
{
  data *grey_word;
  data *current_node = library_head;
  removeFirst();
}

void make_answer(int try_cnt)
{
  data *current_node = library_head;
  data *stored_node = NULL;
  stored_node->score = 0;

  //최대점수를 가진 단어 찾기
  while (current_node->next != NULL){
    if (stored_node->score < current_node->score)
      stored_node = current_node;
    current_node = current_node->next;
  }
  
  for(int i = 0; i < WORD_LEN_MAX; i++)
    results[try_cnt-1].answer[i] = stored_node->word[i];
  results[try_cnt-1].answer[WORD_LEN_MAX] = '\0'; //혹시몰라서 추가해봄
}

int is_correct(const char *result)
{
  for(int i = 0; i < WORD_LEN_MAX; i++){
    if(result[i] != 'g')
      return 0;
  }
  return 1;
}
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<


//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
//Rendering part
void render_start_scene(){
  //rendering
  printf("-----------------\n");
  printf("Wordle game!!\n");
  sleep(1);//delay
}

void render_progress_scene(int try_cnt){
  //rendering
  system("clear");
  printf("\033[0;31m┏━━━┳━━━┳━━━┳━━━┳━━━┓\n");
  for(int i = 0 ; i < TRY_MAX; i++){
    printf("\033[0;31m┃");
    for(int j = 0; j < WORD_LEN_MAX; j++){
      if(i <= try_cnt){
        if(results[i].result[j] == 'b')
          printf("\033[0;100m %c", results[i].result[j]);
        if(results[i].result[j] == 'y')
          printf("\033[0;43m %c", results[i].result[j]);
        if(results[i].result[j] == 'g')
          printf("\033[0;42m %c", results[i].result[j]);
        printf(" \033[0;31m┃");
      }
      else{
        printf("   \033[0;31m┃");
      }
    }
    printf(" \033[0m%s\n", results[i].answer);
    if(i < TRY_MAX-1)
      printf("\033[0;31m┣━━━╋━━━╋━━━╋━━━╋━━━┫\n");
  }
  printf("\033[0;31m┗━━━┻━━━┻━━━┻━━━┻━━━┛\n");
}

void render_end_scene(){
  //rendering
  sleep(1);//delay
}
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<


void start_game(int render_option){
  int try_cnt;

  if(render_option == RENDER_ON){
    sleep(3);//delay
    render_start_scene();
  }
  
  for(try_cnt = 0; try_cnt < TRY_MAX; try_cnt++){

    //make_answer과 guess 함수를 더 복잡하게 사용해서 정답률 높이기
    make_answer(try_cnt);
    guess(results[try_cnt].answer, results[try_cnt].result);
    //you can use the result of guess function
    //if the guess function returns error, there's garbage value in result array

    if(render_option == RENDER_ON)
      render_progress_scene(try_cnt);
    
    if(is_correct(results[try_cnt].result))
      goto finish;    
  }
  
finish:
  if(render_option == RENDER_ON)
    render_end_scene();
}