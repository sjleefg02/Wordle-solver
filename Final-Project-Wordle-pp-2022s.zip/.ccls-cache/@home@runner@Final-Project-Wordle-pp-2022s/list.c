
#define NULL (0)
#include <memory.h>
#include <stdio.h>
#include <stdlib.h>

struct node {
  int data;
  struct node *next;
  struct node *prev;
};

void print_list(struct node *s) {
  if (s != NULL) {
    printf("%d ", s->data);
    print_list(s->next);
  } else {
    printf("NULL\n");
  }
}


void reverse_print_list(struct node *s) {
  if (s != NULL) {
    printf("%d ", s->data);
    reverse_print_list(s->prev);
  } else {
    printf("NULL\n");
  }
}

void insertFront(struct node** head, int data) {
    // allocate memory for newNode
    struct node* newNode = malloc(sizeof(struct node));
    // assign data to newNode
    newNode->data = data;
    // point next of newNode to the first node of the doubly linked list
    newNode->next = (*head);
    // point prev to NULL
    newNode->prev = NULL;
    // point previous of the first node (now first node is the second node) to newNode
    if ((*head) != NULL)
        (*head)->prev = newNode;
    // head points to newNode
    (*head) = newNode;
}

// insert a node after a specific node
void insertAfter(struct node* prev_node, int data) {

    // check if previous node is NULL
    if (prev_node == NULL) {
        printf("previous node cannot be NULL");
        return;
    }

    // allocate memory for newNode
    struct node* newNode  = malloc(sizeof(struct node));
    // assign data to newNode
    newNode->data = data;
    // set next of newNode to next of prev node
    newNode->next = prev_node->next;
    // set next of prev node to newNode
    prev_node->next = newNode;
    // set prev of newNode to the previous node
    newNode->prev = prev_node;
    // set prev of newNode's next to newNode
    if(newNode ->next!= NULL){
    newNode->next->prev = newNode;}
}


// insert a newNode at the end of the list
void insertEnd(struct node** head, int data) {
    // allocate memory for node
    struct node* newNode = malloc(sizeof(struct node));

    // assign data to newNode
    newNode->data = data;

    // assign NULL to next of newNode
    newNode->next = NULL;

    // store the head node temporarily (for later use)
    struct node* temp = *head;

    // if the linked list is empty, make the newNode as head node
    if (*head == NULL) {
        newNode->prev = NULL;
        *head = newNode;
        return;
    }

    // if the linked list is not empty, traverse to the end of the linked list
    while (temp->next != NULL)
        temp = temp->next;
   
    // now, the last node of the linked list is temp

    // point the next of the last node (temp) to newNode.
    temp->next = newNode;

    // assign prev of newNode to temp
    newNode->prev = temp;
}

// delete a node from the doubly linked list
void deleteNode(struct node** head, struct node* del_node) {
  // if head or del is null, deletion is not possible
  if (*head == NULL || del_node == NULL)
    return;

  // if del_node is the head node, point the head pointer to the next of del_node
  if (*head == del_node)
    *head = del_node->next;

  // if del_node is not at the last node, point the prev of node next to del_node to the previous of del_node
  if (del_node->next != NULL)
    del_node->next->prev = del_node->prev;

  // if del_node is not the first node, point the next of the previous node to the next node of del_node
  if (del_node->prev != NULL)
    del_node->prev->next = del_node->next;

  // free the memory of del_node
  free(del_node);
}

int main(void) {
  /* Initialize nodes */
  struct node *head;
  struct node *one = NULL;
  struct node *two = NULL;
  struct node *three = NULL;

  /* Allocate memory */
  one = malloc(sizeof(struct node));
  two = malloc(sizeof(struct node));
  three = malloc(sizeof(struct node));

  /* Assign data values */
  one->data = 1;
  two->data = 2;
  three->data = 3;

  /* Connect nodes */
  one->next = two;
  one->prev = NULL;

  two->next = three;
  two->prev = one;

  three->next = NULL;
  three->prev = two;

  /* Save address of first node in head */
  head = one;

  //insertFront(&head, 10);
  //insertAfter(one, 99);
  insertEnd(&head, 10);

  //reverse_print_list(three);
  print_list(head);
}


/*


Answers below


*/


// insert a node after a specific node
void answer_insertAfter(struct node* prev_node, int data) {

    // check if previous node is NULL
    if (prev_node == NULL) {
        printf("previous node cannot be NULL");
        return;
    }

    // allocate memory for newNode
    struct node* newNode = malloc(sizeof(struct node));

    // assign data to newNode
    newNode->data = data;

    // set next of newNode to next of prev node
    newNode->next = prev_node->next;

    // set next of prev node to newNode
    prev_node->next = newNode;

    // set prev of newNode to the previous node
    newNode->prev = prev_node;

    // set prev of newNode's next to newNode
    if (newNode->next != NULL)
        newNode->next->prev = newNode;
}