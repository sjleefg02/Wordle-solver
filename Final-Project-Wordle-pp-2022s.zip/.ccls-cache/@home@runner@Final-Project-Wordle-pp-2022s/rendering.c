void render_progress_scene(int try_cnt){
  //rendering
  system("clear");
  printf("\033[0;31m┏━━━┳━━━┳━━━┳━━━┳━━━┓\n");
  for(int i = 0 ; i < TRY_MAX; i++){
    printf("\033[0;31m┃");
    for(int j = 0; j < WORD_LEN_MAX; j++){
      if(i <= try_cnt){
        if(results[i].result[j] == 'b')
          printf("\033[0;100m %c", results[i].result[j]);
        if(results[i].result[j] == 'y')
          printf("\033[0;43m %c", results[i].result[j]);
        if(results[i].result[j] == 'g')
          printf("\033[0;42m %c", results[i].result[j]);
        printf(" \033[0;31m┃");
      }
      else{
        printf("   \033[0;31m┃");
      }
    }
    printf(" \033[0m%s\n", results[i].answer);
    if(i < TRY_MAX-1)
      printf("\033[0;31m┣━━━╋━━━╋━━━╋━━━╋━━━┫\n");
  }
  printf("\033[0;31m┗━━━┻━━━┻━━━┻━━━┻━━━┛\n");
}


// 색상 변경
// void render_progress_scene(int try_cnt){
//   //rendering
//   system("clear");
//   printf("\033[0;31m┏━━━┳━━━┳━━━┳━━━┳━━━┓\n");
//   for(int i = 0 ; i < TRY_MAX; i++){
//     printf("\033[0;31m┃");
//     for(int j = 0; j < WORD_LEN_MAX; j++){
//       if(i <= try_cnt){
//         if(results[i].result[j] == 'b')
//           printf(" \033[0;37m%c", results[i].result[j]);
//         if(results[i].result[j] == 'y')
//           printf(" \033[0;33m%c", results[i].result[j]);
//         if(results[i].result[j] == 'g')
//           printf(" \033[0;32m%c", results[i].result[j]);
//         printf(" \033[0;31m┃");
//       }
//       else{
//         printf("   \033[0;31m┃");
//       }
//     }
//     printf(" \033[0m%s\n", results[i].answer);
//     if(i < TRY_MAX-1)
//       printf("\033[0;31m┣━━━╋━━━╋━━━╋━━━╋━━━┫\n");
//   }
//   printf("\033[0;31m┗━━━┻━━━┻━━━┻━━━┻━━━┛\n");
// }

// 기본 코드
// void render_progress_scene(int try_cnt){
//   //rendering
//   system("clear");
//   printf("┏━━━┳━━━┳━━━┳━━━┳━━━┓\n");
//   for(int i = 0 ; i < TRY_MAX; i++){
//     printf("┃");
//     for(int j = 0; j < WORD_LEN_MAX; j++){
//       if(i <= try_cnt){
//         printf(" %c ┃", results[i].result[j]);
//       }
//       else{
//         printf("   ┃");
//       }
//     }
//     printf(" %s\n", results[i].answer);
//     if(i < TRY_MAX-1)
//       printf("┣━━━╋━━━╋━━━╋━━━╋━━━┫\n");
//   }
//   printf("┗━━━┻━━━┻━━━┻━━━┻━━━┛\n");
// }


//ver.1 (X)
// void render_progress_scene(int try_cnt){
//   //rendering
//   system("clear");
//   printf("┏━━━┳━━━┳━━━┳━━━┳━━━┓\n");
//   for(int i = 0 ; i < TRY_MAX; i++){
//     printf("┃");
//     for(int j = 0; j < WORD_LEN_MAX; j++){
//       if(i <= try_cnt){
//         if(results[i].result[j] == 'b')
//           change_text_color(WHITE);
//         else if(results[i].result[j] == 'g')
//           change_text_color(GREEN);
//         else if(results[i].result[j] == 'y')
//           change_text_color(YELLOW);
//         printf(" %c", results[i].result[j]);
//         change_text_color(WHITE);
//         printf(" ┃");
//       }
//       else{
//         printf("   ┃");
//       }
//     }
//     printf(" %s\n", results[i].answer);
//     if(i < TRY_MAX-1)
//       printf("┣━━━╋━━━╋━━━╋━━━╋━━━┫\n");
//   }
//   printf("┗━━━┻━━━┻━━━┻━━━┻━━━┛\n");
//   fflush(stdout);
//   sleep(1);//delay
// }


//ver.2 (X)
// void render_progress_scene(int try_cnt){
//   //rendering
//   system("clear");
//   printf("┏━━━┳━━━┳━━━┳━━━┳━━━┓\n");
//   for(int i = 0 ; i < TRY_MAX; i++){
//     change_text_color(GRAY);
//     printf("┃");
//     for(int j = 0; j < WORD_LEN_MAX; j++){
//       if(i <= try_cnt){
//         if(results[i].result[j] == 'b')
//           change_text_color(WHITE);
//         else if(results[i].result[j] == 'g')
//           change_text_color(GREEN);
//         else if(results[i].result[j] == 'y')
//           change_text_color(YELLOW);
//         printf(" %c", results[i].result[j]);
//         change_text_color(GRAY);
//         printf(" ┃");
//       }
//       else{
//         change_text_color(GRAY);
//         printf("   ┃");
//       }
//     }
//     printf(" %s\n", results[i].answer);
//     if(i < TRY_MAX-1)
//       printf("┣━━━╋━━━╋━━━╋━━━╋━━━┫\n");
//   }
//   printf("┗━━━┻━━━┻━━━┻━━━┻━━━┛\n");
//   fflush(stdout);
//   sleep(1);//delay
// }