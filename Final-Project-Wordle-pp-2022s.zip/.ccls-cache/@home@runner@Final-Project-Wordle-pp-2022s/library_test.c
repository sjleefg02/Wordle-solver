#include "wordle_st.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h> //for sleep

#define MAX_WORD 30000
#define WORD_LEN_MAX 5
#define TRY_MAX 6
#define ALPHABET_CNT 26

double point[ALPHABET_CNT] = {8.2,  1.5,  2.8, 4.3,  13,  2.2,  2,   6.1,   7,
                              0.15, 0.77, 4,   2.4,  6.7, 7.5,  1.9, 0.095, 6,
                              6.3,  9.1,  2.8, 0.98, 2.4, 0.15, 2,   0.074};

struct word_status {
  char answer[WORD_LEN_MAX + 1];
  char result[WORD_LEN_MAX + 1];
};

struct word_status results[TRY_MAX];

struct word_data {
  char *word;
  double score;
  int unused_letter_cnt;
  struct word_data *next;
};
typedef struct word_data data;

//word[i] = tolower(word[i]);
int unused_letter_count(char* word){
  int word_letter_cnt = 0;
  // B, J, K, Q, X, Z 의 개수를 세는 프로그램
    char used[6] = {0,};
    for (int i = 0; i < WORD_LEN_MAX; i++) {
      if (word[i] == 'b') {used[0] = 1;}
      if (word[i] == 'j') {used[1] = 1;}
      if (word[i] == 'k') {used[2] = 1;}
      if (word[i] == 'q') {used[3] = 1;}
      if (word[i] == 'x') {used[4] = 1;}
      if (word[i] == 'z') {used[5] = 1;}
    }
    for (int i = 0; i < WORD_LEN_MAX; i++) {
      if (used[i] == 1) {word_letter_cnt += 1;}
      }
  return word_letter_cnt;
}

double score_count(char* word){
  double word_score = 0;
  for (int i = 0; i < WORD_LEN_MAX; i++) {
      word_score += point[word[i] - 'a'];
    }
  return word_score;
}

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
// Initializing part
void build_word_lib(const char *file_path) // const char *file_path
{ 
  int c;
  FILE *fp = fopen(file_path, "r");
  data *prev_node = NULL;
  data * head = NULL;
  int check_prev = 0;

  while ((c = getc(fp)) != EOF) {
    char word[WORD_LEN_MAX + 1];
    int cnt_len = 0;
    word[cnt_len++] = c;
    while (1) {
      c = getc(fp);
      word[cnt_len++] = c;
      if (cnt_len == WORD_LEN_MAX) {
        cnt_len = 0;
        c = getc(fp);
        break;
      }
      word[WORD_LEN_MAX] = '\0';
    }
    printf("word : %s",word);
  }
  fclose(fp);
  
}


